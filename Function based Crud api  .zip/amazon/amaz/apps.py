from django.apps import AppConfig


class AmazConfig(AppConfig):
    name = 'amaz'
    def ready(self):
        import amaz.mysignal
