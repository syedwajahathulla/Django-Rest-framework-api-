from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, RegexValidator

# Create your models here.
class Myprofile(models.Model):
    name = models.CharField(max_length = 100)
    user = models.OneToOneField(to=User, on_delete=models.CASCADE, null=True,blank=True )
    phone_no = models.CharField(validators=[RegexValidator("^0?[5-9]{1}\d{9}$")], max_length=15, null=True, blank=True)
    pic = models.ImageField(default= 'default.png' , null=True,blank=True )

    def __str__(self):
        return self.name 

class Products(models.Model):
    title = models.CharField(max_length = 30)
    pic = models.ImageField(default= 'default.png' , null=True,blank=True )
    description = models.TextField(max_length = 1000)
    price = models.FloatField()

    def __str__(self):
        return self.title 
