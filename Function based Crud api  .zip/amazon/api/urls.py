from django.urls import path
from .import views

urlpatterns = [
    path('',views.apiOverview, name="api-overview"),
    path('products/',views.products, name="products"),
    path('product-details/<str:pk>/',views.productsdetails, name="product-details"),
    path('create-product/',views.createproducts, name="create-product"),
    path('update-product/<str:pk>/',views.updateproducts, name="update-product"),
    path('delete-product/<str:pk>/',views.deleteproducts, name="delete-product"),
]

