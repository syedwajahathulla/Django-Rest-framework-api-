from django.shortcuts import render
from django.http import JsonResponse

from rest_framework.decorators import api_view
from rest_framework.response import Response

from amaz.models import *
from .serializers import *
# Create your views here.

@api_view(['GET'])
def apiOverview(request):
    api_urls = {
        #products
        'products':'/products/',
        'product-details':'product-details/<str:pk>/',
        'create-product':'create-product/',
        'update-product':'update-product/<str:pk>/',
        'delete-product':'delete-product/<str:pk>/',
    }
    return Response(api_urls)

@api_view(['GET'])
def products(request):
    products = Products.objects.all()
    serializer = ProductsSerializer(products, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def productsdetails(request,pk):
    products = Products.objects.get(id=pk)
    serializer = ProductsSerializer(products, many=False)
    return Response(serializer.data)

@api_view(['POST'])
def createproducts(request):
    serializer = ProductsSerializer(request.data)
    if serializer.is_valid:
        serializer.save()

    return Response(serializer.data)

@api_view(['POST'])
def updateproducts(request,pk):
    products = Products.objects.get(id=pk)
    serializer = ProductsSerializer(instance=products, data=request.data)
    if serializer.is_valid:
        serializer.save()
    return Response(serializer.data)

@api_view(['DELETE'])
def deleteproducts(request,pk):
    products = Products.objects.get(id=pk)
    products.delete()

    return Response(products)